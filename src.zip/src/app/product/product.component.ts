import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import {products}
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
encodeURI
  constructor(private movieService : MoviesService) { }

