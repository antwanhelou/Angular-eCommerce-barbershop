import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  card = [
    {
      title: 'Card Title 1',
      social:'<i class="fab fa-facebook-f"></i>'
     
      
    },
    {
      title: 'Card Title 2',
      
    },
    {
      title: 'Card Title 3',
     
    },
    {
      title: 'Card Title 4',
      
     
    },

  ];

}
